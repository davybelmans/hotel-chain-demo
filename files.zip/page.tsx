import { headers } from 'next/headers'
import { notFound } from 'next/navigation'
import client from '@/lib/storyblok/client'
import { StoryblokRenderer } from '@/components/StoryblokRenderer'

interface Props {
  params: {
    locale: string
    slug?: string[]
  }
}

export default async function Page({ params }: Props) {
  const headersList = headers()
  const folder = headersList.get('x-hotel-folder') ?? 'hotel-alfa'

  // Bouw het Storyblok pad op
  // /nl → hotels/hotel-alfa/pages/home
  // /nl/rooms/superior-room → hotels/hotel-alfa/rooms/superior-room
  const slugParts = params.slug ?? ['home']

  // Bepaal submap op basis van eerste slug segment
  const isRoom = slugParts[0] === 'rooms'
  const storyPath = isRoom
    ? `hotels/${folder}/rooms/${slugParts.slice(1).join('/') || 'index'}`
    : `hotels/${folder}/pages/${slugParts.join('/')}`

  try {
    const { data } = await client.getStory(storyPath, {
      version: 'draft',
      language: params.locale,
    })

    const bloks = data.story.content.body ?? []

    return (
      <div>
        <StoryblokRenderer bloks={bloks} />
      </div>
    )
  } catch {
    notFound()
  }
}

export const revalidate = 3600
