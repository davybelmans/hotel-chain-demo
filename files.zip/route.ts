import { NextRequest } from 'next/server'
import { getHotelByDomain } from '@/lib/storyblok/resolve-hotel'

export async function GET(request: NextRequest) {
  const domain = request.nextUrl.searchParams.get('domain')

  if (!domain) {
    return Response.json({ error: 'Geen domein opgegeven' }, { status: 400 })
  }

  const hotel = await getHotelByDomain(domain)

  if (!hotel) {
    return Response.json({ error: 'Hotel niet gevonden' }, { status: 404 })
  }

  return Response.json(hotel)
}
